module.exports = {
    runtimeCompiler: true
}

