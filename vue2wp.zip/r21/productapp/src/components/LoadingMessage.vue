<template>
    <h3 class="bg-info text-white text-center m-2 p-2">
        Komponent ładowany leniwie...
    </h3>
</template>

