<template>
    <div class="bg-primary text-white text-center m-2 p-3">
        <h3>Produkt: {{ name | capitalize | reverse }}</h3> 
        <h4>Cena: {{ getTotalPrice(lowTaxRate) | currency(3) }} (Niższa stawka)</h4>
        <h4>Cena: {{ getTotalPrice(highTaxRate) | currency }} (Wyższa stawka)</h4>
    </div>
</template>
<script>
    export default {
        name: "MyComponent",
        data: function () {
             return {
                   name: "Kamizelka ratunkowa", 
                   price: 48.95, 
                   lowTaxRate: 12, 
                   highTaxRate: 20
               } 
        },
        methods: {
            getTotalPrice(taxRate) {
                return this.price + (this.price * (taxRate / 100));
            }
        }, 
        filters: {
            currency(value, places) {
                return new Intl.NumberFormat("pl-PL",
                  {
                      style: "currency", currency: "PLN",
                      minimumFractionDigits: places || 2,
                      maximumFractionDigits: places || 2
                 }).format(value);
            },
            capitalize(value) {
                return value[0].toUpperCase() + value.slice(1);
            },
            reverse(value) {
                return value.split("").reverse().join("");
            }
       } 
   }
</script>
