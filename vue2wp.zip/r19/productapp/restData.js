module.exports = function () {
    var data = {
        products: [
            { id: 1, name: "Kajak", category: "Sporty wodne", price: 275 },
            { id: 2, name: "Kamizelka ratunkowa", category: "Sporty wodne", price: 48.95 },
            { id: 3, name: "Piłka nożna", category: "Piłka nożna", price: 19.50 },
            { id: 4, name: "Chorągiewki narożne", category: "Piłka nożna", price: 34.95 },
            { id: 5, name: "Stadion", category: "Piłka nożna", price: 79500 },
            { id: 6, name: "Myśląca czapeczka", category: "Szachy", price: 16 },
            { id: 7, name: "Chwiejne krzesło", category: "Szachy", price: 29.95 },
            { id: 8, name: "Szachownica", category: "Szachy", price: 75 },
            { id: 9, name: "Król(u) złoty", category: "Szachy", price: 1200 }
        ] 
    }
    return data 
}

