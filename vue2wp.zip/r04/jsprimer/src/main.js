console.log('Cześć!');
