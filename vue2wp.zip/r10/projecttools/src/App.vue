<template>
    <div id="app">
           <h1>Liczba kliknięć: {{ counter }}</h1>
            <button v-on:click="incrementCounter">Wciśnij mnie</button> 
            <div id="nav">
                <router-link to="/">Strona główna</router-link> |
                <router-link to="/about">O mnie</router-link>
            </div>
        <router-view />
    </div>
</template>
<script>
export default {
    //ta instrukcja nie jest prawidłowa!
    data() {
        return {
            counter: 0 
        }
    }, 
    methods: {
        incrementCounter() {
            //debugger;
            this.counter++;
     } 
   }
}
</script>
<style>
    #app {
        font-family: 'Avenir', Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: center;
        color: #2c3e50;
    }
    #nav {
        padding: 30px;
     }
     #nav a.router-link-exact-active {
            color: #42b983;
     } 
</style>

