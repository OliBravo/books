<template>
    <div class="container-fluid text-center">
        <div class="bg-primary text-white m-2 p-3">
            <h3 v-bind:text-content.prop="textContent"></h3>
        </div>
        <button v-on:click="handleClick" class="btn btn-primary">
            Wciśnij mnie
        </button>
    </div>
</template>
<script>
    export default {
        name: "MyComponent",
        data: function () {
            return {
                name: "Kamizelka ratunkowa",
                highlight: false,
            } 
     },
     computed: {
            textContent() {
                return this.highlight ? "Podświetlenie!" : `Produkt: ${this.name}`;
            }
     }, 
      methods: {
            handleClick() {
                this.highlight = !this.highlight;
            } 
       }
  } 
</script>

