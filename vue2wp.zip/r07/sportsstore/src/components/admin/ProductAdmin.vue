<template>
    <div class="bg-danger text-white text-center h4 p-2">
        Zarządzanie produktami
    </div>
</template>

